@echo off
setlocal
title Surat Smart Metro AI Launcher

echo ======================================================
echo    Surat Smart Metro AI Chatbot - Auto Launcher
echo ======================================================
echo.

REM 1. Verify Python is available
python --version >nul 2>&1
if %errorlevel% neq 0 (
    echo [ERROR] Python is not installed or not added to PATH!
    echo Please install Python from https://www.python.org/
    echo Make sure to check 'Add Python to PATH' during installation.
    echo.
    pause
    exit /b 1
)

REM 2. Verify or create virtual environment
if not exist "venv\Scripts\streamlit.exe" (
    echo [1/3] Creating virtual environment 'venv'...
    python -m venv venv
    echo [2/3] Installing dependencies...
    call ".\venv\Scripts\pip.exe" install -r requirements.txt
    echo Dependencies installed successfully!
)

REM 3. Verify .env file
if not exist ".env" (
    if exist ".env.example" (
        copy .env.example .env >nul
    )
)

REM 4. Verify vector index
if not exist "faiss_index\index.faiss" (
    echo [3/3] Generating local vector database...
    call ".\venv\Scripts\python.exe" rag.py
)

REM 5. Launch application
echo.
echo ======================================================
echo    Starting Surat Smart Metro Chatbot...
echo    Opening browser at http://localhost:8501
echo ======================================================
echo.

call ".\venv\Scripts\streamlit.exe" run app.py --server.fileWatcherType none

pause
