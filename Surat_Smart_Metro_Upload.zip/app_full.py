import html
import streamlit as st
from markdown_it import MarkdownIt
from chatbot import get_response

# Initialize markdown-it renderer with tables support
md = MarkdownIt("commonmark").enable("table").enable("strikethrough")

# ---------- PAGE CONFIGURATION ----------
st.set_page_config(
    page_title="Surat Smart Metro AI",
    page_icon="🚇",
    layout="centered",
    initial_sidebar_state="expanded"
)

# ---------- CUSTOM STYLES (Modern Dark Transit UI) ----------
st.markdown("""
<style>
    /* Main Background & Base Typography */
    .stApp {
        background: radial-gradient(circle at 50% 0%, #171b22 0%, #0d0f12 70%);
        color: #e2e8f0;
        font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
    }

    /* Fix Streamlit Header & Content Padding */
    header[data-testid="stHeader"] {
        background: transparent !important;
    }
    .block-container {
        padding-top: 1.8rem !important;
        padding-bottom: 6.5rem !important;
        max-width: 780px !important;
    }

    /* Top Brand Navigation Header */
    .brand-header {
        display: flex;
        align-items: center;
        justify-content: space-between;
        background: rgba(21, 24, 30, 0.85);
        backdrop-filter: blur(14px);
        border: 1px solid rgba(255, 255, 255, 0.08);
        border-radius: 18px;
        padding: 14px 22px;
        margin-bottom: 24px;
        box-shadow: 0 8px 30px rgba(0, 0, 0, 0.35);
    }
    .brand-left {
        display: flex;
        align-items: center;
        gap: 14px;
    }
    .brand-icon-box {
        background: linear-gradient(135deg, #0284c7, #6366f1);
        width: 44px;
        height: 44px;
        border-radius: 12px;
        display: flex;
        align-items: center;
        justify-content: center;
        font-size: 22px;
        box-shadow: 0 4px 15px rgba(2, 132, 199, 0.35);
    }
    .brand-title {
        margin: 0;
        font-size: 1.25rem;
        font-weight: 700;
        letter-spacing: -0.02em;
        color: #ffffff;
    }
    .brand-title span {
        background: linear-gradient(90deg, #38bdf8, #818cf8);
        -webkit-background-clip: text;
        -webkit-text-fill-color: transparent;
    }
    .brand-subtitle {
        margin: 2px 0 0 0;
        font-size: 0.8rem;
        color: #94a3b8;
    }
    .status-pill {
        display: inline-flex;
        align-items: center;
        gap: 7px;
        background: rgba(34, 197, 94, 0.12);
        border: 1px solid rgba(34, 197, 94, 0.28);
        color: #4ade80;
        font-size: 0.76rem;
        font-weight: 600;
        padding: 5px 12px;
        border-radius: 20px;
    }
    .pulse-dot {
        width: 7px;
        height: 7px;
        background-color: #22c55e;
        border-radius: 50%;
        box-shadow: 0 0 8px #22c55e;
        animation: pulse 2s infinite;
    }
    @keyframes pulse {
        0%, 100% { opacity: 1; transform: scale(1); }
        50% { opacity: 0.4; transform: scale(0.85); }
    }

    /* Chat Message Rows & Alignment (WhatsApp / ChatGPT style) */
    .chat-row {
        display: flex;
        align-items: flex-start;
        gap: 12px;
        margin: 14px 0;
        width: 100%;
    }
    .user-row {
        justify-content: flex-end;
    }
    .assistant-row {
        justify-content: flex-start;
    }

    /* Avatars */
    .chat-avatar {
        width: 36px;
        height: 36px;
        min-width: 36px;
        display: flex;
        align-items: center;
        justify-content: center;
        font-size: 18px;
        user-select: none;
        flex-shrink: 0;
    }
    .user-avatar {
        background: #1e293b;
        border: 1px solid #334155;
        border-radius: 50%;
        box-shadow: 0 2px 8px rgba(0, 0, 0, 0.3);
    }
    .assistant-avatar {
        background: linear-gradient(135deg, #0284c7, #6366f1);
        border-radius: 12px;
        box-shadow: 0 4px 14px rgba(2, 132, 199, 0.35);
    }

    /* Message Bubbles */
    .chat-bubble {
        padding: 12px 18px;
        font-size: 0.94rem;
        line-height: 1.6;
        word-break: break-word;
        overflow-wrap: break-word;
    }

    /* User Bubble (Right Aligned, Distinct Vibrant Blue) */
    .user-bubble {
        background: linear-gradient(135deg, #2563eb, #1d4ed8);
        border: 1px solid #3b82f6;
        color: #ffffff !important;
        border-radius: 18px 4px 18px 18px;
        max-width: 75%;
        width: fit-content;
        box-shadow: 0 4px 16px rgba(37, 99, 235, 0.28);
        font-weight: 450;
    }

    /* Assistant Bubble (Left Aligned, Modern Dark Elevated Card) */
    .assistant-bubble {
        background: #13161c;
        border: 1px solid rgba(255, 255, 255, 0.08);
        color: #e2e8f0;
        border-radius: 4px 18px 18px 18px;
        max-width: 80%;
        width: fit-content;
        box-shadow: 0 6px 25px rgba(0, 0, 0, 0.35);
    }
    .assistant-bubble p {
        margin: 0 0 8px 0;
    }
    .assistant-bubble p:last-child {
        margin-bottom: 0;
    }
    .assistant-bubble strong {
        color: #ffffff;
    }
    .assistant-bubble ul, .assistant-bubble ol {
        margin: 6px 0 10px 0;
        padding-left: 20px;
    }
    .assistant-bubble li {
        margin-bottom: 4px;
    }

    /* Markdown Table Formatting */
    table {
        width: 100% !important;
        border-collapse: collapse !important;
        margin: 14px 0 !important;
        background: #0f1217 !important;
        border-radius: 8px !important;
        overflow: hidden !important;
        border: 1px solid #272d38 !important;
    }
    th {
        background: #1c222b !important;
        color: #38bdf8 !important;
        font-weight: 600 !important;
        padding: 10px 14px !important;
        text-align: left !important;
        border-bottom: 1px solid #2e3544 !important;
    }
    td {
        padding: 9px 14px !important;
        border-bottom: 1px solid #1f2530 !important;
        color: #cbd5e1 !important;
        font-size: 0.92rem !important;
    }
    tr:last-child td {
        border-bottom: none !important;
    }
    tr:nth-child(even) {
        background: rgba(255, 255, 255, 0.02) !important;
    }

    /* Prompt Suggestion Card Grid */
    .suggestions-container {
        margin-top: 15px;
        margin-bottom: 25px;
    }
    .suggestion-label {
        font-size: 0.85rem;
        font-weight: 600;
        color: #94a3b8;
        margin-bottom: 10px;
        text-transform: uppercase;
        letter-spacing: 0.05em;
    }
    div.stButton > button {
        background: #161a22 !important;
        color: #cbd5e1 !important;
        border: 1px solid #282f3c !important;
        border-radius: 12px !important;
        padding: 10px 14px !important;
        font-size: 0.88rem !important;
        font-weight: 500 !important;
        width: 100% !important;
        text-align: left !important;
        transition: all 0.2s ease !important;
    }
    div.stButton > button:hover {
        background: #1e2430 !important;
        border-color: #38bdf8 !important;
        color: #ffffff !important;
        box-shadow: 0 4px 12px rgba(56, 189, 248, 0.2) !important;
        transform: translateY(-1px) !important;
    }

    /* Chat Input Styling */
    div[data-testid="stChatInput"] {
        max-width: 780px !important;
        margin: 0 auto !important;
    }
    div[data-testid="stChatInput"] > div {
        background: #13161c !important;
        border: 1px solid #2d3542 !important;
        border-radius: 28px !important;
        box-shadow: 0 8px 30px rgba(0, 0, 0, 0.5) !important;
        transition: border-color 0.2s ease, box-shadow 0.2s ease !important;
    }
    div[data-testid="stChatInput"] > div:focus-within {
        border-color: #38bdf8 !important;
        box-shadow: 0 0 20px rgba(56, 189, 248, 0.25) !important;
    }
    div[data-testid="stChatInput"] textarea {
        color: #f1f5f9 !important;
        font-size: 0.96rem !important;
    }

    /* Sidebar Clean Dark Styling */
    section[data-testid="stSidebar"] {
        background: #0f1217 !important;
        border-right: 1px solid #1f2530 !important;
    }
    .sidebar-card {
        background: #161a22;
        border: 1px solid #252b37;
        border-radius: 14px;
        padding: 14px 16px;
        margin-bottom: 14px;
    }
    .sidebar-title {
        font-size: 0.9rem;
        font-weight: 700;
        color: #f8fafc;
        margin-bottom: 8px;
        display: flex;
        align-items: center;
        gap: 8px;
    }
    .sidebar-text {
        font-size: 0.82rem;
        color: #94a3b8;
        line-height: 1.5;
        margin: 0;
    }

    /* Custom Scrollbar */
    ::-webkit-scrollbar { width: 7px; height: 7px; }
    ::-webkit-scrollbar-track { background: transparent; }
    ::-webkit-scrollbar-thumb { background: #282f3c; border-radius: 10px; }
    ::-webkit-scrollbar-thumb:hover { background: #38bdf8; }
</style>
""", unsafe_allow_html=True)

# ---------- SIDEBAR NAVIGATION & INFO ----------
with st.sidebar:
    st.markdown("""
    <div style="display:flex; align-items:center; gap:10px; margin-bottom:16px;">
        <span style="font-size:26px;">🚇</span>
        <h3 style="margin:0; font-size:1.15rem; color:#f8fafc;">Surat Metro Guide</h3>
    </div>
    """, unsafe_allow_html=True)

    st.markdown("""
    <div class="sidebar-card">
        <div class="sidebar-title"><span style="color:#ef4444;">🔴</span> Red Line (Line 1)</div>
        <p class="sidebar-text"><b>Sarthana ↔ DREAM City</b><br>16 Stations • 21.6 km<br>Key stops: Railway Station, Majura Gate, VIP Road</p>
    </div>

    <div class="sidebar-card">
        <div class="sidebar-title"><span style="color:#22c55e;">🟢</span> Green Line (Line 2)</div>
        <p class="sidebar-text"><b>Bhesan ↔ Saroli</b><br>11 Stations • 18.7 km<br>Key stops: Botanical Garden, Majura Gate, Magob</p>
    </div>

    <div class="sidebar-card">
        <div class="sidebar-title"><span style="color:#f59e0b;">🔄</span> Central Interchange</div>
        <p class="sidebar-text"><b>Majura Gate</b> connects both the Red and Green lines for seamless passenger transfer.</p>
    </div>

    <div class="sidebar-card">
        <div class="sidebar-title"><span style="color:#38bdf8;">🕒</span> Metro Schedule</div>
        <p class="sidebar-text">
        • <b>Peak Hours:</b> 6:00 AM – 11:00 AM (every 6-8m)<br>
        • <b>Regular:</b> 11:00 AM – 5:00 PM (every 10m)<br>
        • <b>Evening Peak:</b> 5:00 PM – 10:00 PM (every 6-7m)<br>
        • <b>Last Train:</b> ~10:30 PM - 11:00 PM
        </p>
    </div>
    """, unsafe_allow_html=True)

    if st.button("🗑️ Clear Conversation", use_container_width=True):
        st.session_state.messages = [
            {"role": "assistant", "content": "Hello! 👋 I am your Surat Metro assistant. Feel free to ask anything about routes, fares, or station information."}
        ]
        st.rerun()

# ---------- TOP BRAND HEADER ----------
st.markdown("""
<div class="brand-header">
    <div class="brand-left">
        <div class="brand-icon-box">🚇</div>
        <div>
            <h1 class="brand-title">Surat <span>Smart Metro</span></h1>
            <p class="brand-subtitle">AI-Powered Transit Guide for Routes, Fares & Timings</p>
        </div>
    </div>
    <div class="status-pill">
        <span class="pulse-dot"></span>
        Operational
    </div>
</div>
""", unsafe_allow_html=True)

# ---------- SESSION STATE INITIALIZATION ----------
if "messages" not in st.session_state:
    st.session_state.messages = [
        {"role": "assistant", "content": "Hello! 👋 I am your Surat Metro assistant. Feel free to ask anything about routes, fares, or station information."}
    ]

# ---------- CHAT MESSAGES DISPLAY (WhatsApp / ChatGPT Style) ----------
for msg in st.session_state.messages:
    if msg["role"] == "user":
        escaped_user_content = html.escape(msg["content"]).replace("\n", "<br>")
        st.markdown(f"""
        <div class="chat-row user-row">
            <div class="chat-bubble user-bubble">{escaped_user_content}</div>
            <div class="chat-avatar user-avatar">👤</div>
        </div>
        """, unsafe_allow_html=True)
    else:
        rendered_assistant_content = md.render(msg["content"])
        st.markdown(f"""
        <div class="chat-row assistant-row">
            <div class="chat-avatar assistant-avatar">🚇</div>
            <div class="chat-bubble assistant-bubble">{rendered_assistant_content}</div>
        </div>
        """, unsafe_allow_html=True)

# ---------- QUICK SUGGESTION CHIPS (STARTER PROMPTS) ----------
user_prompt = None

if len(st.session_state.messages) <= 1:
    st.markdown('<div class="suggestions-container"><div class="suggestion-label">Suggested Inquiries</div></div>', unsafe_allow_html=True)
    col1, col2 = st.columns(2)
    with col1:
        if st.button("🗺️ Route: Sarthana to DREAM City"):
            user_prompt = "What is the route from Sarthana to DREAM City?"
        if st.button("🔄 How to interchange at Majura Gate?"):
            user_prompt = "How does the interchange work at Majura Gate station?"
    with col2:
        if st.button("🎫 What is the fare structure?"):
            user_prompt = "What is the fare chart and minimum fare for Surat Metro?"
        if st.button("⏰ First & Last Train Timings"):
            user_prompt = "What are the first and last train timings and peak hour schedule?"

# ---------- CHAT INPUT & EXECUTION ----------
chat_input_val = st.chat_input("Ask about Surat Metro routes, fares, timings...")

if chat_input_val:
    user_prompt = chat_input_val

if user_prompt:
    st.session_state.messages.append({"role": "user", "content": user_prompt})

    with st.spinner("Analyzing transit data..."):
        response = get_response(user_prompt)

    st.session_state.messages.append({"role": "assistant", "content": response})
    st.rerun()