import os
from dotenv import load_dotenv
from langchain_groq import ChatGroq
from langchain_community.vectorstores import FAISS
from langchain_huggingface import HuggingFaceEmbeddings
from langchain_core.prompts import ChatPromptTemplate
from tools import find_route, calculate_fare, get_station_info

load_dotenv()

# Groq Model
llm = ChatGroq(
    model="openai/gpt-oss-20b",
    temperature=0.2,
    api_key=os.getenv("GROQ_API_KEY")
)

# Load Vector Store (metro knowledge base)
embeddings = HuggingFaceEmbeddings(model_name="sentence-transformers/all-MiniLM-L6-v2")
vectorstore = FAISS.load_local("faiss_index", embeddings, allow_dangerous_deserialization=True)
retriever = vectorstore.as_retriever(search_kwargs={"k": 3})

# Tools
tools = [find_route, calculate_fare, get_station_info]
llm_with_tools = llm.bind_tools(tools)

def get_response(user_input: str):
    try:
        # 1. Retrieve relevant information from data
        docs = retriever.invoke(user_input)
        context = "\n\n".join([doc.page_content for doc in docs])

        # 2. Build system prompt
        system_prompt = f"""You are a helpful Surat Smart Metro assistant.
Always answer based on the following data:

{context}

Rules:
- Reply in clear, polite English
- If user asks for route, fare, or station info, use the appropriate tools
- Only rely on the provided context and tool outputs
- If information is not available, say "I have limited information regarding this query."
"""

        messages = [
            ("system", system_prompt),
            ("human", user_input)
        ]

        response = llm_with_tools.invoke(messages)

        # If a tool call was triggered
        if hasattr(response, "tool_calls") and response.tool_calls:
            tool_outputs = []

            for tool_call in response.tool_calls:
                tool_name = tool_call["name"]
                tool_args = tool_call["args"]

                if tool_name == "find_route":
                    result = find_route.invoke(tool_args)
                elif tool_name == "calculate_fare":
                    result = calculate_fare.invoke(tool_args)
                elif tool_name == "get_station_info":
                    result = get_station_info.invoke(tool_args)
                else:
                    result = "Tool not found"

                tool_outputs.append(f"{tool_name} → {result}")

            final_prompt = f"""User asked: {user_input}

Tool information:
{chr(10).join(tool_outputs)}

Context from data:
{context}

Based on this information, provide a helpful and clear response in English."""
            
            final_response = llm.invoke(final_prompt)
            return final_response.content

        return response.content

    except Exception as e:
        return f"Error: {str(e)}"